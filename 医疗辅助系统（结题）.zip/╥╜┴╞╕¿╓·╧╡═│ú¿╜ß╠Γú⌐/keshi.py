import gradio as gr
import mysql.connector

# MySQL connection setup
mysql_conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="patient"
)
mysql_cursor = mysql_conn.cursor()

def show_department_appointments(department_name):
    # Query to join 'users' and 'registration' tables based on department name
    query = '''
        SELECT registration.id, registration.patient_id, users.username, users.appointment_time, users.registration_time
        FROM registration
        INNER JOIN users ON registration.patient_id = users.id
        WHERE registration.recommended_department = %s
    '''
    mysql_cursor.execute(query, (department_name,))
    department_appointments = mysql_cursor.fetchall()

    appointments_info = "\n".join([
        f"ID: {app[0]}, User ID: {app[1]}, Username: {app[2]}, Appointment Time: {app[3]}, Registration Time: {app[4]}"
        for app in department_appointments
    ])

    return f"科室: {department_name} 预约详情", appointments_info

iface_department_appointments = gr.Interface(
    fn=show_department_appointments,
    inputs=gr.Textbox(label="输入查询科室"),
    outputs=[
        gr.Textbox(label="查询科室"),
        gr.Textbox(label="科室预约详情")
    ],
    title="查询某科室患者预约记录",
    description="请输入科室名称展示科室预约详情"
)

iface_department_appointments.launch(share=True)