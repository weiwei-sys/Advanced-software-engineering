import pandas as pd
import mysql.connector

# MySQL 数据库连接
mysql_conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="patient"
)
mysql_cursor = mysql_conn.cursor()

# 查询在相同预约时间段内挂号两次的用户
mysql_cursor.execute('''
    SELECT u.* 
    FROM users u
    WHERE EXISTS (
        SELECT 1
        FROM users u2
        WHERE u.username = u2.username
            AND u.appointment_time = u2.appointment_time
            AND u.id != u2.id
    )
''')

# 获取查询结果
duplicate_users = mysql_cursor.fetchall()

if duplicate_users:
    # 创建 DataFrame 存储查询结果
    df_duplicate_users = pd.DataFrame(duplicate_users, columns=["id", "username", "appointment_time", "medical_condition", "registration_time"])

    # 将结果导出到 Excel 文件
    excel_filename = "duplicate_users.xlsx"
    df_duplicate_users.to_excel(excel_filename, index=False)

    print(f"用户在相同预约时间段内挂号两次的信息已导出到 {excel_filename}")
else:
    print("没有发现在相同预约时间段内挂号两次的用户")

# 关闭数据库连接
mysql_conn.close()
