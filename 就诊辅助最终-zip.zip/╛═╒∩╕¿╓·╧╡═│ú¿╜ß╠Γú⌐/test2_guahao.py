import gradio as gr
import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
import mysql.connector
from datetime import datetime

# Read data from Excel file
df = pd.read_excel('correspondingDepartment.xlsx')

# Assuming the columns in the Excel file are named "病情描述" (symptom) and "科室名称" (department)

# Create the model
model = make_pipeline(CountVectorizer(), MultinomialNB())
model.fit(df['病情描述'], df['科室名称'])

# Define the model prediction function
def predict_department(symptom):
    return model.predict([symptom])[0]

# MySQL 数据库连接
mysql_conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="patient"
)
mysql_cursor = mysql_conn.cursor()

mysql_cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(255),
        appointment_time VARCHAR(255),
        medical_condition TEXT,
        registration_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )
''')
mysql_conn.commit()

# 创建 registration 表
mysql_cursor.execute('''
    CREATE TABLE IF NOT EXISTS registration (
        id INT AUTO_INCREMENT PRIMARY KEY,
        patient_id INT,
        patient_name VARCHAR(255),
        recommended_department VARCHAR(255)
    )
''')
mysql_conn.commit()

def combined_function(username, appointment_time, medical_condition, operation):
    if operation == "register":
        try:
            # 获取当前时间
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

            # 向 MySQL 数据库插入用户信息
            mysql_cursor.execute('''
                INSERT INTO users (username, appointment_time, medical_condition, registration_time) 
                VALUES (%s, %s, %s, %s)
            ''', (str(username), str(appointment_time), str(medical_condition), current_time))
            mysql_conn.commit()

            registration_result = f"{username} 已成功挂号，预约时间为 {appointment_time}"

            # 替换成推荐科室的逻辑

            recommended_department = predict_department(medical_condition)

            # 向 registration 表插入推荐科室和用户信息
            mysql_cursor.execute('''
                INSERT INTO registration (patient_id, patient_name, recommended_department) 
                VALUES (%s, %s, %s)
            ''', (mysql_cursor.lastrowid, str(username), recommended_department))
            mysql_conn.commit()

            return registration_result, recommended_department
        except mysql.connector.IntegrityError:
            return "用户名已存在，请重新选择用户名", ""
    elif operation == "show":
        # 查询 MySQL 数据库中的用户
        mysql_cursor.execute("SELECT * FROM users")
        mysql_users = mysql_cursor.fetchall()

        mysql_user_list = "\n".join([f"ID: {user[0]}, Username: {user[1]}, Appointment Time: {user[2]}, Medical Condition: {user[3]}, Registration Time: {user[4]}" for user in mysql_users])

        return "展示预约患者记录", mysql_user_list  # 返回两个值，挂号结果和用户列表

iface_combined = gr.Interface(
    fn=combined_function,
    inputs=[
        gr.Textbox(label="患者姓名"),
        gr.Textbox(label="预约时间"),
        gr.Textbox(label="病情描述"),
        gr.Radio(["register", "show"], label="操作")],
    outputs=[
        gr.Textbox(label="预约患者信息"),
        gr.Textbox(label="推荐科室")
    ],
    title="用户挂号系统",
    description="请输入您的姓名、预约时间和病情描述进行挂号或显示所有患者信息"
)

iface_combined.launch(share=True)
