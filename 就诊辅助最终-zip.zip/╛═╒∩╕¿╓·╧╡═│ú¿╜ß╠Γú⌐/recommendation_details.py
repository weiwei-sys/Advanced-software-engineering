import gradio as gr
import mysql.connector

# MySQL 数据库连接
mysql_conn = mysql.connector.connect(
    host="localhost",
    user="root",
    password="123456",
    database="patient"
)
mysql_cursor = mysql_conn.cursor()

def show_recommendation_details(result_type):
    if result_type == "success":
        # 查询推荐成功的用户，即在 registration 表中找到的记录数为 1 的用户
        query = '''
            SELECT u.* 
            FROM users u
            INNER JOIN registration r ON u.id = r.patient_id
            WHERE r.recommended_department IS NOT NULL
            GROUP BY u.username
            HAVING COUNT(r.id) = 1
        '''
        mysql_cursor.execute(query)
        success_users = mysql_cursor.fetchall()

        # 计算用户个数
        user_count = len(success_users)

        # 构建用户信息字符串
        users_info = "\n".join([
            f"ID: {user[0]}, Username: {user[1]}, Appointment Time: {user[2]}, Medical Condition: {user[3]}, Registration Time: {user[4]}"
            for user in success_users
        ])

        return f"推荐成功详情（共 {user_count} 人）", users_info
    elif result_type == "failure":
        # 查询推荐失败的用户，即在 registration 表中找到的记录数大于 1 的用户
        query = '''
            SELECT u.* 
            FROM users u
            INNER JOIN registration r ON u.id = r.patient_id
            WHERE r.recommended_department IS NOT NULL
            GROUP BY u.username
            HAVING COUNT(r.id) > 1
        '''
        mysql_cursor.execute(query)
        failure_users = mysql_cursor.fetchall()

        # 计算用户个数
        user_count = len(failure_users)

        # 构建用户信息字符串
        users_info = "\n".join([
            f"ID: {user[0]}, Username: {user[1]}, Appointment Time: {user[2]}, Medical Condition: {user[3]}, Registration Time: {user[4]}"
            for user in failure_users
        ])

        return f"推荐失败详情（共 {user_count} 人）", users_info
    else:
        return "无效的操作类型", ""

iface_recommendation_details = gr.Interface(
    fn=show_recommendation_details,
    inputs=gr.Radio(["success", "failure"], label="选择操作类型"),
    outputs=[
        gr.Textbox(label="推荐详情"),
        gr.Textbox(label="用户信息")
    ],
    title="推荐详情查询系统",
    description="请选择推荐成功或推荐失败来查看相应的用户信息"
)

iface_recommendation_details.launch(share=True)
