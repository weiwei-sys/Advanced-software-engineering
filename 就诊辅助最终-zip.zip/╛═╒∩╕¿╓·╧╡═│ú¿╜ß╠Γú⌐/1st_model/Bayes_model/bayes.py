import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score
from googletrans import Translator

# 读取Excel文件
df = pd.read_excel('Symptom2DiseaseNew12_15.xlsx')

# 划分数据集
X_train, X_test, y_train, y_test = train_test_split(df['疾病描述'], df['科室名称'], test_size=0.2, random_state=42)

# 创建模型管道
model = make_pipeline(CountVectorizer(), MultinomialNB())

# 训练模型
model.fit(X_train, y_train)

# 在测试集上进行预测
y_pred = model.predict(X_test)

# 评估模型性能
accuracy = accuracy_score(y_test, y_pred)
print(f'模型准确率: {accuracy}')

# 初始化翻译器
translator = Translator()

# 通过用户输入进行预测
user_input = input("请输入疾病的描述: ")

def predict_department(user_input):
    # 将中文输入翻译成英文
    translated_input = translator.translate(user_input, src='zh-cn', dest='en').text
    # 使用模型进行预测
    predicted_department_en = model.predict([translated_input])
    # 将英文科室名称翻译成中文
    predicted_department_cn = translator.translate(predicted_department_en[0], src='en', dest='zh-cn').text
    # 打印预测的科室名称
    print(f'预测的科室名称: {predicted_department_cn}')
    return predicted_department_cn
while(1):
    predict_department(user_input)
    user_input = input("请输入疾病的描述: ")

